@extends('template.template')

@section('content')
    @if ($notification = Session::get('success'))
        <div class="alert alert-success alert-block">
            <strong>{{ $notification }}</strong>
        </div>
    @endif
    @if ($notification = Session::get('error'))
        <div class="alert alert-danger alert-block">
            <strong>{{ $notification }}</strong>
        </div>
    @endif
    {{-- <div class="container-fluid">
        <div class="card shadow mb-4">
            <div class="card-body"> --}}
    <div class="table-responsive">
        {{ $dataTable->table() }}
    </div>
    {{-- </div>
        </div>
    </div> --}}
@endsection

@push('scripts')
    {{ $dataTable->scripts(attributes: ['type' => 'module']) }}
@endpush
