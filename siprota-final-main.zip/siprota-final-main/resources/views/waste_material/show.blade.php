@extends('template.template')

@section('content')
    @if ($notification = Session::get('success'))
        <div class="alert alert-success alert-block">
            <strong>{{ $notification }}</strong>
        </div>
    @endif
    @if ($notification = Session::get('error'))
        <div class="alert alert-danger alert-block">
            <strong>{{ $notification }}</strong>
        </div>
    @endif
    <div class="container-fluid">
        <div class="card shadow mb-4">
            <div class="card-body">
                <div class="row">
                    <div class="col">
                        {{-- download pdf --}}
                        <a href="{{ route('waste-material.pdf', $waste_materials->id) }}"
                            class="btn btn-sm btn-danger shadow-sm">
                            <i class="fas fa-download fa-sm text-white-50"></i> Download PDF
                        </a>
                    </div>
                </div>

                <hr class="sidebar-divider">

                <div class="row">
                    <div class="col-5">Nama Region</div>
                    <div class="col-2">:</div>
                    <div class="col-5">{{ $nama_region }}</div>
                </div>

                {{-- separator --}}
                <hr class="sidebar-divider">

                <div class="row">
                    <div class="col-5">Nama Gudang</div>
                    <div class="col-2">:</div>
                    <div class="col-5">{{ $nama_gudang }}</div>
                </div>

                {{-- separator --}}
                <hr class="sidebar-divider">

                <div class="row">
                    <div class="col-5">ID Barang</div>
                    <div class="col-2">:</div>
                    <div class="col-5">{{ $waste_materials->id_barang }}</div>
                </div>

                {{-- separator --}}
                <hr class="sidebar-divider">

                <div class="row">
                    <div class="col-5">Nama Barang</div>
                    <div class="col-2">:</div>
                    <div class="col-5">{{ $waste_materials->nama_barang }}</div>
                </div>

                {{-- separator --}}
                <hr class="sidebar-divider">

                <div class="row">
                    <div class="col-5">Jenis Barang</div>
                    <div class="col-2">:</div>
                    <div class="col-5">{{ $waste_materials->jenis_barang }}</div>
                </div>

                {{-- separator --}}
                <hr class="sidebar-divider">

                <div class="row">
                    <div class="col-5">Kategori</div>
                    <div class="col-2">:</div>
                    <div class="col-5">{{ $waste_materials->kategori }}</div>
                </div>

                {{-- separator --}}
                <hr class="sidebar-divider">

                <div class="row">
                    <div class="col-5">Volume</div>
                    <div class="col-2">:</div>
                    <div class="col-5">{{ $waste_materials->volume }}</div>
                </div>

                {{-- separator --}}
                <hr class="sidebar-divider">

                <div class="row">
                    <div class="col-5">Satuan</div>
                    <div class="col-2">:</div>
                    <div class="col-5">{{ $waste_materials->satuan }}</div>
                </div>
                {{-- separator --}}
                <hr class="sidebar-divider">

                <div class="row">
                    <div class="col-5">Keterangan</div>
                    <div class="col-2">:</div>
                    <div class="col-5">{{ $waste_materials->keterangan }}</div>
                </div>

                {{-- separator --}}
                <hr class="sidebar-divider">

                <div class="row">
                    <div class="col-5">Tahun Produksi</div>
                    <div class="col-2">:</div>
                    <div class="col-5">{{ $waste_materials->tahun_produksi }}</div>
                </div>

                <hr class="sidebar-divider">

                <div class="row">
                    <div class="col-5">Bukti Barang </div>
                    <div class="col-3">
                        <img src="{{ asset('storage/' . $waste_materials->foto) }}" alt=""
                            style="width: auto; height: auto">
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
