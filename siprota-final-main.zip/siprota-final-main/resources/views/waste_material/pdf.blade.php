<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">

    <!-- font poppins  -->

    <title>Generate Kartu Peserta</title>

    <style>
        /*
        1.atas
        2.
        3.
        4.kanan
    */

        @page {
            margin: 50px 25px 0 25px;
        }

        .page2 {
            page-break-before: always;
        }
    </style>
</head>

<body>
    <div class="container-fluid">
        <div class="card shadow mb-4">
            <div class="card-body">
                <div class="row">
                    <div class="col-5">Nama Region : {{ $nama_region }}</div>
                </div>

                {{-- separator --}}
                <hr class="sidebar-divider">

                <div class="row">
                    <div class="col-5">Nama Gudang : {{ $nama_gudang }}</div>
                </div>

                {{-- separator --}}
                <hr class="sidebar-divider">

                <div class="row">
                    <div class="col-5">ID Barang : {{ $waste_materials->id_barang }}</div>
                </div>

                {{-- separator --}}
                <hr class="sidebar-divider">

                <div class="row">
                    <div class="col-5">Nama Barang : {{ $waste_materials->nama_barang }}</div>
                </div>

                {{-- separator --}}
                <hr class="sidebar-divider">

                <div class="row">
                    <div class="col-5">Jenis Barang : {{ $waste_materials->jenis_barang }}</div>
                </div>

                {{-- separator --}}
                <hr class="sidebar-divider">

                <div class="row">
                    <div class="col-5">Kategori : {{ $waste_materials->kategori }}</div>
                </div>

                {{-- separator --}}
                <hr class="sidebar-divider">

                <div class="row">
                    <div class="col-5">Volume : {{ $waste_materials->volume }}</div>
                </div>

                {{-- separator --}}
                <hr class="sidebar-divider">

                <div class="row">
                    <div class="col-5">Satuan : {{ $waste_materials->satuan }}</div>
                </div>
                {{-- separator --}}
                <hr class="sidebar-divider">

                <div class="row">
                    <div class="col-5">Keterangan : {{ $waste_materials->keterangan }}</div>
                </div>

                {{-- separator --}}
                <hr class="sidebar-divider">

                <div class="row">
                    <div class="col-5">Tahun Produksi : {{ $waste_materials->tahun_produksi }}</div>
                </div>

                <hr class="sidebar-divider">

                <div class="row">
                    <div class="col-5">Bukti Barang : </div>
                    <div class="col-5">
                        <img src="{{ public_path('/storage/') . $waste_materials->foto }}" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="/assets/vendor/jquery/jquery.min.js"></script>
    <script src="/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="/assets/vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="/assets/js/sb-admin-2.min.js"></script>


    <script src="/assets/vendor/datatables/jquery.dataTables.js"></script>
    <script src="/assets/vendor/datatables/dataTables.bootstrap4.min.js"></script>
</body>

</html>
