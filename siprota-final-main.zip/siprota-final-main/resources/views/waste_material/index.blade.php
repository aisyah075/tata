@extends('template.template')

@section('content')
    @if ($notification = Session::get('success'))
        <div class="alert alert-success alert-block">
            <strong>{{ $notification }}</strong>
        </div>
    @endif
    @if ($notification = Session::get('error'))
        <div class="alert alert-danger alert-block">
            <strong>{{ $notification }}</strong>
        </div>
    @endif
    <div class="container-fluid">
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <a href="{{ route('waste-material.create') }}" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                <i class="fas fa-plus fa-sm text-white-50"></i> Create New
            </a>
        </div>
        <div class="card shadow mb-4">
            <div class="card-body">
                <div class="row">
                    <div class="col">
                        {{-- download pdf --}}
                        <a href="{{ url('/waste-material/excel/download') }}" class="btn btn-sm btn-danger shadow-sm">
                            <i class="fas fa-download fa-sm text-white-50"></i> Download Excel
                        </a>
                    </div>
                </div>

                <hr class="sidebar-divider">

                <div class="table-responsive">
                    {{ $dataTable->table() }}
                </div>
            </div>
        </div>
    </div>
@endsection

@push('scripts')
    {{ $dataTable->scripts(attributes: ['type' => 'module']) }}

    <script>
        $('#mwastematerial-table').DataTable({
            buttons: [
                'copy', 'excel', 'pdf'
            ]
        });
    </script>
@endpush
