@extends('template.template')

@section('content')
    @if ($notification = Session::get('success'))
        <div class="alert alert-success alert-block">
            <strong>{{ $notification }}</strong>
        </div>
    @endif
    @if ($notification = Session::get('error'))
        <div class="alert alert-danger alert-block">
            <strong>{{ $notification }}</strong>
        </div>
    @endif
    <form action="{{ route('waste-material.update', $waste_material->id) }}" method="POST" id="form">
        @csrf
        {{ method_field('PUT') }}
        <div class="form-group">
            <label for="name">Name</label>
            <input type="text" name="name" id="name" class="form-control"
                value="{{ $waste_material->nama_barang }}">
        </div>
        <div class="form-group">
            <label for="gudang">Pilih Nama Gudang</label>
            <select name="gudang" id="gudang" class="form-control">
                <option value="" disabled selected>Pilih Gudang</option>
                @foreach ($gudangs as $g)
                    <option value="{{ $g->id }}" {{ $g->id == $waste_material->gudang_id ? 'selected' : '' }}>
                        {{ $g->name }}</option>
                @endforeach
            </select>
        </div>
        <div class="form-group">
            <label for="region">Pilih Nama Region</label>
            <select name="region" id="region" class="form-control">
            </select>
        </div>
        <?php
        $curr_year = date('Y');
        $curr_month = date('m');
        $curr_day = date('d');
        ?>
        <div class="form-group">
            <label for="tahun_masuk">Tahun Masuk</label>
            <input type="number" name="tahun_masuk" id="tahun_masuk" class="form-control" value="{{ $curr_year }}">
        </div>
        <div class="form-group">
            <label for="bulan_masuk">Bulan Masuk</label>
            <input type="number" name="bulan_masuk" id="bulan_masuk" class="form-control" value="{{ $curr_month }}">
        </div>
        <div class="form-group">
            <label for="tanggal_masuk">Tanggal Masuk</label>
            <input type="number" name="tanggal_masuk" id="tanggal_masuk" class="form-control" value="{{ $curr_day }}">
        </div>
        <div class="form-group">
            <video id="video" width="640" height="480" autoplay></video>
            <button id="capture-btn" class="btn btn-success">Capture</button>
            <input type="hidden" id="captured-image" name="foto" value="" class="form-control">
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-primary" id="main-submit-btn">Submit</button>
        </div>
    </form>
    <script>
        const mainSubmitBtn = document.getElementById('main-submit-btn');

        // Add a click event listener to the main submit button
        mainSubmitBtn.addEventListener('click', function(event) {
            // Manually submit the form by calling the submit method on the form element
            const form = document.getElementById('form');
            form.submit();
        });
        document.getElementById('form').addEventListener('submit', function(event) {
            event.preventDefault(); // Prevent the default form submit behavior
            // Your code to process the form data here
        });

        const video = document.getElementById('video');
        const captureBtn = document.getElementById('capture-btn');
        const capturedImageInput = document.getElementById('captured-image');

        // Get user media and display it in the video element
        navigator.mediaDevices.getUserMedia({
                video: true
            })
            .then(stream => {
                video.srcObject = stream;
                video.play();
            })
            .catch(error => console.error(error));

        // Capture image and set it as the value of the hidden input field
        captureBtn.addEventListener('click', () => {
            video.pause();
            const canvas = document.createElement('canvas');
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            canvas.getContext('2d').drawImage(video, 0, 0, canvas.width, canvas.height);
            capturedImageInput.value = canvas.toDataURL('image/png');
        });
        $(document).ready(function() {
            $('#gudang').on('change', function() {
                var gudang_id = $(this).val();
                if (gudang_id) {
                    $.ajax({
                        url: '/waste-material/get-region/' + gudang_id,
                        type: "GET",
                        dataType: "json",
                        success: function(data) {
                            $('#region').empty();
                            $.each(data, function(key, value) {
                                console.log(key, value);
                                $('#region').append('<option value="' + key + '">' +
                                    value.name + '</option>');
                            });
                        },
                    });
                } else {
                    $('#region').empty();
                }
            });
        });
    </script>
@endsection
