composer require laravel/ui
php artisan ui bootstrap --auth
npm install
composer require bfinlay/laravel-excel-seeder
composer require yajra/laravel-datatables
composer require barryvdh/laravel-dompdf
composer require maatwebsite/excel
php artisan vendor:publish --provider="Maatwebsite\Excel\ExcelServiceProvider" --tag=config

sudo chmod -R 755 storage/
sudo chmod -R ugo+rw storage/
sudo chmod -R 755 bootstrap/cache/
sudo chmod -R ugo+rw bootstrap/cache/