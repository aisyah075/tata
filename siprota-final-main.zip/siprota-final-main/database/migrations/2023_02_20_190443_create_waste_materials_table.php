<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('waste_materials', function (Blueprint $table) {
            $table->id();
            $table->string('id_barang')->nullable();
            $table->string('nama_barang')->nullable();
            $table->string('jenis_barang')->nullable();
            $table->string('kategori')->nullable();
            $table->string('volume')->nullable();
            $table->string('satuan')->nullable();
            $table->string('keterangan')->nullable();
            $table->string('tahun_produksi')->nullable();
            $table->integer('tahun_masuk')->unsigned()->nullable();
            $table->integer('bulan_masuk')->unsigned()->nullable();
            $table->integer('tanggal_masuk')->unsigned()->nullable();
            $table->string('foto')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('waste_materials');
    }
};
