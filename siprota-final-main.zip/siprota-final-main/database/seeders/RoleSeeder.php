<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use App\Models\Role;

class RoleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('roles')->insert([
            [
                'name' => 'admin',
                'description' => 'Administrator',
            ],
            [
                'name' => 'Regional 1',
                'description' => 'Regional 1',
            ],
            [
                'name' => 'Regional 2',
                'description' => 'Regional 2',
            ],
            [
                'name' => 'Regional 3',
                'description' => 'Regional 3',
            ],
            [
                'name' => 'Regional 4',
                'description' => 'Regional 4',
            ],
            [
                'name' => 'Regional 5',
                'description' => 'Regional 5',
            ],
            [
                'name' => 'Regional 6',
                'description' => 'Regional 6',
            ],
            [
                'name' => 'Regional 7',
                'description' => 'Regional 7',
            ],
            [
                'name' => 'HO',
                'description' => 'HO',
            ],
        ]);
    }
}
