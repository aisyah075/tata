<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

use Database\Seeders\RoleSeeder;
use bfinlay\SpreadsheetSeeder\SpreadsheetSeeder;



class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call([
            SpreadsheetSeeder::class,
            WasteMaterialUpdateSeeder::class,
            UserSeeder::class,
            RoleSeeder::class,
            UserRoleSeeder::class,
            RegionSeeder::class,
            GudangSeeder::class,
            GudangRegionalSeeder::class,
        ]);
    }
}
