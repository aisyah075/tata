<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class GudangSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('gudangs')->insert([
            [
                "name" => "Aceh",
            ],
            [
                "name" => "SO Langsa",
            ],
            [
                "name" => "SO Lhokseumawe",
            ],
            [
                "name" => "SO Meulaboh",
            ],
            [
                "name" => "Pematang Siantar",
            ],
            [
                "name" => "SO Kabanjahe",
            ],
            [
                "name" => "SO Kisaran",
            ],
            [
                "name" => "SO Padang sidempuan",
            ],
            [
                "name" => "SO Pematang Siantar",
            ],
            [
                "name" => "SO Rantau Prapat",
            ],
            [
                "name" => "SO Sibolga",
            ],
            [
                "name" => "Medan",
            ],
            [
                "name" => "SO Binjai",
            ],
            [
                "name" => "SO Lubuk Pakam",
            ],
            [
                "name" => "SO Medan",
            ],
            [
                "name" => "SO Padang Bulan",
            ],
            [
                "name" => "SO Pulo Brayan",
            ],
            [
                "name" => "SO Simpang Limun",
            ],
            [
                "name" => "SO Suka Ramai",
            ],
            [
                "name" => "SO Tanjung Morawa",
            ],
            [
                "name" => "SO Tanjung Mulia",
            ],
            [
                "name" => "Pekanbaru",
            ],
            [
                "name" => "SO Arengka",
            ],
            [
                "name" => "SO Dumai",
            ],
            [
                "name" => "SO Duri",
            ],
            [
                "name" => "SO Rengat",
            ],
            [
                "name" => "SO Rumbai",
            ],
            [
                "name" => "SO Tembilahan",
            ],
            [
                "name" => "SO Ujung Batu",
            ],
            [
                "name" => "Batam",
            ],
            [
                "name" => "SO Lubuk Baja",
            ],
            [
                "name" => "SO Batam Center",
            ],
            [
                "name" => "SO Sagulung",
            ],
            [
                "name" => "SO Tanjung Balai Karimun",
            ],
            [
                "name" => "SO Tanjung Pinang",
            ],
            [
                "name" => "Padang",
            ],
            [
                "name" => "SO Bukit Tinggi",
            ],
            [
                "name" => "SO Padang",
            ],
            [
                "name" => "SO Payakumbuh",
            ],
            [
                "name" => "SO Solok",
            ],
            [
                "name" => "SO Ulakarang",
            ],
            [
                "name" => "SO Muara Enim",
            ],
            [
                "name" => "Palembang",
            ],
            [
                "name" => "SO Baturaja",
            ],
            [
                "name" => "SO Kayu Agung",
            ],
            [
                "name" => "SO Kenten Ujung",
            ],
            [
                "name" => "SO Lahat",
            ],
            [
                "name" => "SO Lubuk Linggau",
            ],
            [
                "name" => "SO Palembang Ilir",
            ],
            [
                "name" => "SO Prabumulih",
            ],
            [
                "name" => "SO Seberang Ulu",
            ],
            [
                "name" => "SO Sekayu",
            ],
            [
                "name" => "SO Talang Kelapa",
            ],
            [
                "name" => "Bangka Belitung",
            ],
            [
                "name" => "SO Koba",
            ],
            [
                "name" => "SO Mentok",
            ],
            [
                "name" => "SO Sungai Liat",
            ],
            [
                "name" => "SO Tanjung Pandan",
            ],
            [
                "name" => "Jambi",
            ],
            [
                "name" => "SO Muara Bungo",
            ],
            [
                "name" => "SO Sarolangon",
            ],
            [
                "name" => "Bengkulu",
            ],
            [
                "name" => "SO Arga Makmur",
            ],
            [
                "name" => "SO Bengkulu",
            ],
            [
                "name" => "SO Curup",
            ],
            [
                "name" => "SO Manna",
            ],
            [
                "name" => "Lampung",
            ],
            [
                "name" => "SO Kota Bumi",
            ],
            [
                "name" => "SO Liwa",
            ],
            [
                "name" => "SO Metro",
            ],
            [
                "name" => "SO Unit 2",
            ],
            [
                "name" => "Bekasi",
            ],
            [
                "name" => "SO Bantar Gebang",
            ],
            [
                "name" => "SO Bekasi",
            ],
            [
                "name" => "SO Cikarang",
            ],
            [
                "name" => "SO Jababeka",
            ],
            [
                "name" => "SO Kaliabang",
            ],
            [
                "name" => "SO Kranji",
            ],
            [
                "name" => "SO Pekayon",
            ],
            [
                "name" => "SO Pondok Gede",
            ],
            [
                "name" => "SO Sukaresmi",
            ],
            [
                "name" => "Jakarta Timur",
            ],
            [
                "name" => "SO Cawang",
            ],
            [
                "name" => "SO Gandaria",
            ],
            [
                "name" => "SO Jatinegara",
            ],
            [
                "name" => "SO Klender",
            ],
            [
                "name" => "SO Kranggan",
            ],
            [
                "name" => "SO Pasar Rebo",
            ],
            [
                "name" => "SO Penggilingan",
            ],
            [
                "name" => "SO Pondok Kelapa",
            ],
            [
                "name" => "SO Pulo Gebang",
            ],
            [
                "name" => "SO Rawamangun",
            ],
            [
                "name" => "Jakarta Utara",
            ],
            [
                "name" => "SO Cilincing",
            ],
            [
                "name" => "SO Kelapa Gading",
            ],
            [
                "name" => "SO Kota",
            ],
            [
                "name" => "SO Manggabesar",
            ],
            [
                "name" => "SO Muara Karang",
            ],
            [
                "name" => "SO Pademangan",
            ],
            [
                "name" => "SO Sunter",
            ],
            [
                "name" => "Jakarta Pusat",
            ],
            [
                "name" => "SO Cideng",
            ],
            [
                "name" => "SO Cikini",
            ],
            [
                "name" => "SO Gambir",
            ],
            [
                "name" => "SO Kemayoran",
            ],
            [
                "name" => "Jakarta Barat",
            ],
            [
                "name" => "SO Cengkareng A",
            ],
            [
                "name" => "SO Cengkareng B",
            ],
            [
                "name" => "SO Kedoya",
            ],
            [
                "name" => "SO Meruya",
            ],
            [
                "name" => "SO Semanggi",
            ],
            [
                "name" => "SO Slipi",
            ],
            [
                "name" => "Jakarta Selatan",
            ],
            [
                "name" => "SO Bintaro",
            ],
            [
                "name" => "SO Jagakarsa",
            ],
            [
                "name" => "SO Kalibata",
            ],
            [
                "name" => "SO Keb Baru",
            ],
            [
                "name" => "SO Kemang",
            ],
            [
                "name" => "SO Pasa Minggu",
            ],
            [
                "name" => "SO Tebet",
            ],
            [
                "name" => "Bogor",
            ],
            [
                "name" => "SO Bogor Centrum",
            ],
            [
                "name" => "SO Ciawi",
            ],
            [
                "name" => "SO Cibinong",
            ],
            [
                "name" => "SO Cileungsi",
            ],
            [
                "name" => "SO Cisarua",
            ],
            [
                "name" => "SO Depok",
            ],
            [
                "name" => "SO Dramaga",
            ],
            [
                "name" => "SO Gunung Putri",
            ],
            [
                "name" => "SO Kedung Halang",
            ],
            [
                "name" => "SO Sukmajaya",
            ],
            [
                "name" => "Tangerang",
            ],
            [
                "name" => "SO Ciledug",
            ],
            [
                "name" => "SO Cipondoh",
            ],
            [
                "name" => "SO Ciputat",
            ],
            [
                "name" => "SO Gandasari",
            ],
            [
                "name" => "SO Legok",
            ],
            [
                "name" => "SO Lengkong",
            ],
            [
                "name" => "SO Pakulonan",
            ],
            [
                "name" => "SO Pasar Kemis",
            ],
            [
                "name" => "SO Pondok Aren",
            ],
            [
                "name" => "SO Serpong",
            ],
            [
                "name" => "SO Tangerang",
            ],
            [
                "name" => "Serang",
            ],
            [
                "name" => "SO Cikupa",
            ],
            [
                "name" => "SO Cilegon",
            ],
            [
                "name" => "SO Pandeglang",
            ],
            [
                "name" => "SO Rangkasbitung",
            ],
            [
                "name" => "SO Malingping",
            ],
            [
                "name" => "SO Menes",
            ],
            [
                "name" => "Bandung",
            ],
            [
                "name" => "SO Achmad Yani Bandung",
            ],
            [
                "name" => "SO Bandung Centrum",
            ],
            [
                "name" => "SO Cijawura",
            ],
            [
                "name" => "SO Geger Kalong",
            ],
            [
                "name" => "SO Kopo",
            ],
            [
                "name" => "SO Ujung Berung",
            ],
            [
                "name" => "SO Banjaran",
            ],
            [
                "name" => "SO Padalarang",
            ],
            [
                "name" => "SO Rajawali",
            ],
            [
                "name" => "Sukabumi",
            ],
            [
                "name" => "SO Cianjur",
            ],
            [
                "name" => "SO Cibadak",
            ],
            [
                "name" => "SO Pelabuhan Ratu",
            ],
            [
                "name" => "SO Sindanglaya",
            ],
            [
                "name" => "Bandung Barat",
            ],
            [
                "name" => "SO Majalaya",
            ],
            [
                "name" => "SO Cimahi",
            ],
            [
                "name" => "Cirebon",
            ],
            [
                "name" => "SO Cirebon",
            ],
            [
                "name" => "SO Indramayu",
            ],
            [
                "name" => "SO Karyamulya",
            ],
            [
                "name" => "SO Kuningan Jabar",
            ],
            [
                "name" => "SO Majalengka",
            ],
            [
                "name" => "SO Plered",
            ],
            [
                "name" => "Tasikmalaya",
            ],
            [
                "name" => "SO Banjar",
            ],
            [
                "name" => "SO Ciamis",
            ],
            [
                "name" => "SO Garut",
            ],
            [
                "name" => "SO Singaparna",
            ],
            [
                "name" => "SO Tasikmalaya",
            ],
            [
                "name" => "Karawang",
            ],
            [
                "name" => "SO Cikampek",
            ],
            [
                "name" => "SO Karawang",
            ],
            [
                "name" => "SO Purwakarta",
            ],
            [
                "name" => "SO Subang",
            ],
            [
                "name" => "Semarang",
            ],
            [
                "name" => "SO Banyumanik",
            ],
            [
                "name" => "SO Candi",
            ],
            [
                "name" => "SO Johar",
            ],
            [
                "name" => "SO Kendal",
            ],
            [
                "name" => "SO Majapahit",
            ],
            [
                "name" => "SO Simpang Lima",
            ],
            [
                "name" => "SO Tugu",
            ],
            [
                "name" => "SO Ungaran",
            ],
            [
                "name" => "Pekalongan",
            ],
            [
                "name" => "SO Batang",
            ],
            [
                "name" => "SO Brebes",
            ],
            [
                "name" => "SO Pemalang",
            ],
            [
                "name" => "SO Slawi",
            ],
            [
                "name" => "SO Tegal",
            ],
            [
                "name" => "Yogyakarta",
            ],
            [
                "name" => "SO Bantul",
            ],
            [
                "name" => "SO Kentungan",
            ],
            [
                "name" => "SO Kotabaru",
            ],
            [
                "name" => "SO Pugeran",
            ],
            [
                "name" => "SO Sleman",
            ],
            [
                "name" => "Purwokerto",
            ],
            [
                "name" => "SO Banjarnegara",
            ],
            [
                "name" => "SO Cilacap",
            ],
            [
                "name" => "SO Purbalingga",
            ],
            [
                "name" => "Magelang",
            ],
            [
                "name" => "SO Kebumen",
            ],
            [
                "name" => "SO Mungkid",
            ],
            [
                "name" => "SO Purworejo",
            ],
            [
                "name" => "SO Temanggung",
            ],
            [
                "name" => "SO Wonosobo",
            ],
            [
                "name" => "Solo",
            ],
            [
                "name" => "SO Boyolali",
            ],
            [
                "name" => "SO Gladak",
            ],
            [
                "name" => "SO Grogol",
            ],
            [
                "name" => "SO Karanganyar",
            ],
            [
                "name" => "SO Kartosuro",
            ],
            [
                "name" => "SO Klaten",
            ],
            [
                "name" => "SO Palur",
            ],
            [
                "name" => "SO Salatiga",
            ],
            [
                "name" => "SO Sragen",
            ],
            [
                "name" => "SO Sukoharjo",
            ],
            [
                "name" => "SO Wonogiri",
            ],
            [
                "name" => "Kudus",
            ],
            [
                "name" => "SO Blora",
            ],
            [
                "name" => "SO Demak",
            ],
            [
                "name" => "SO Jepara",
            ],
            [
                "name" => "SO Kudus",
            ],
            [
                "name" => "SO Pati",
            ],
            [
                "name" => "SO Purwodadi",
            ],
            [
                "name" => "Madura",
            ],
            [
                "name" => "SO Bangkalan",
            ],
            [
                "name" => "SO Sumenep",
            ],
            [
                "name" => "SO Gresik",
            ],
            [
                "name" => "SO Kapasan",
            ],
            [
                "name" => "SO Lakarsantri",
            ],
            [
                "name" => "SO Lamongan",
            ],
            [
                "name" => "SO Mergoyoso",
            ],
            [
                "name" => "SO Tandes",
            ],
            [
                "name" => "Surabaya Utara",
            ],
            [
                "name" => "Surabaya Kebalen",
            ],
            [
                "name" => "SO Darmo",
            ],
            [
                "name" => "SO Gubeng",
            ],
            [
                "name" => "SO Injoko",
            ],
            [
                "name" => "SO Manyar",
            ],
            [
                "name" => "SO Rungkut",
            ],
            [
                "name" => "SO Waru2",
            ],
            [
                "name" => "Sidoarjo",
            ],
            [
                "name" => "SO Jombang",
            ],
            [
                "name" => "SO Krian",
            ],
            [
                "name" => "SO Mojokerto",
            ],
            [
                "name" => "SO Pandaan",
            ],
            [
                "name" => "Pasuruan",
            ],
            [
                "name" => "SO Lumajang",
            ],
            [
                "name" => "SO Pasuruan",
            ],
            [
                "name" => "SO Probolinggo",
            ],
            [
                "name" => "Malang",
            ],
            [
                "name" => "SO Batu",
            ],
            [
                "name" => "SO Blimbing",
            ],
            [
                "name" => "SO Kepanjen",
            ],
            [
                "name" => "SO Malang Kota",
            ],
            [
                "name" => "SO Sawojajar",
            ],
            [
                "name" => "SO Singosari",
            ],
            [
                "name" => "SO Turen",
            ],
            [
                "name" => "Jember",
            ],
            [
                "name" => "SO Banyuwangi",
            ],
            [
                "name" => "SO Bondowoso",
            ],
            [
                "name" => "SO Genteng",
            ],
            [
                "name" => "SO Jember 2",
            ],
            [
                "name" => "SO Jember Kota",
            ],
            [
                "name" => "SO Situbondo",
            ],
            [
                "name" => "SO Tanggul",
            ],
            [
                "name" => "Kediri",
            ],
            [
                "name" => "SO Blitar",
            ],
            [
                "name" => "SO Kediri",
            ],
            [
                "name" => "SO Kertosono",
            ],
            [
                "name" => "SO Mojoroto",
            ],
            [
                "name" => "SO Nganjuk",
            ],
            [
                "name" => "SO Pare",
            ],
            [
                "name" => "SO Trenggalek",
            ],
            [
                "name" => "SO Tulungagung",
            ],
            [
                "name" => "SO Wlingi",
            ],
            [
                "name" => "Madiun",
            ],
            [
                "name" => "SO Bojonegoro",
            ],
            [
                "name" => "SO Madiun",
            ],
            [
                "name" => "SO Magetan",
            ],
            [
                "name" => "SO Ngawi",
            ],
            [
                "name" => "SO Pacitan",
            ],
            [
                "name" => "SO Ponorogo",
            ],
            [
                "name" => "SO Tuban",
            ],
            [
                "name" => "Denpasar",
            ],
            [
                "name" => "SO Jimbaran",
            ],
            [
                "name" => "SO Kaliasem",
            ],
            [
                "name" => "SO Kuta",
            ],
            [
                "name" => "SO Sanur",
            ],
            [
                "name" => "SO Ubung",
            ],
            [
                "name" => "Singaraja",
            ],
            [
                "name" => "SO Gianyar",
            ],
            [
                "name" => "SO Semarapura",
            ],
            [
                "name" => "SO Tabanan",
            ],
            [
                "name" => "Mataram",
            ],
            [
                "name" => "SO Bima",
            ],
            [
                "name" => "SO Mataram",
            ],
            [
                "name" => "SO Selong",
            ],
            [
                "name" => "SO Sumbawa",
            ],
            [
                "name" => "Kupang",
            ],
            [
                "name" => "SO Ende",
            ],
            [
                "name" => "SO Waingapu",
            ],
            [
                "name" => "Balikpapan",
            ],
            [
                "name" => "SO Balikpapan Baru",
            ],
            [
                "name" => "SO Penajam",
            ],
            [
                "name" => "SO Muara Jawa",
            ],
            [
                "name" => "SO Tanah Grogot",
            ],
            [
                "name" => "Palangkaraya",
            ],
            [
                "name" => "SO Buntok",
            ],
            [
                "name" => "SO Cilik Riwut",
            ],
            [
                "name" => "SO Imam Bonjol",
            ],
            [
                "name" => "SO Kuala Kapuas",
            ],
            [
                "name" => "SO Muara Teweh",
            ],
            [
                "name" => "SO Pangkalan Bun",
            ],
            [
                "name" => "SO Puruk Cahu",
            ],
            [
                "name" => "SO Sampit",
            ],
            [
                "name" => "SO Gunungsari",
            ],
            [
                "name" => "Banjarmasin",
            ],
            [
                "name" => "SO Banjarbaru",
            ],
            [
                "name" => "SO Banjarmasin Centrum",
            ],
            [
                "name" => "SO Banjarmasin A.Yani",
            ],
            [
                "name" => "SO Barabai",
            ],
            [
                "name" => "SO Batulicin",
            ],
            [
                "name" => "SO Tabalong",
            ],
            [
                "name" => "SO Siantan",
            ],
            [
                "name" => "Pontianak",
            ],
            [
                "name" => "SO Ketapang",
            ],
            [
                "name" => "SO Mempawah",
            ],
            [
                "name" => "SO Pontianak A.Yani",
            ],
            [
                "name" => "SO Teungku Umar",
            ],
            [
                "name" => "SO Sanggau",
            ],
            [
                "name" => "SO Singkawang",
            ],
            [
                "name" => "SO Sintang",
            ],
            [
                "name" => "Samarinda",
            ],
            [
                "name" => "SO Bontang",
            ],
            [
                "name" => "SO Samarinda Centrum",
            ],
            [
                "name" => "SO Sangata",
            ],
            [
                "name" => "SO Tenggarong",
            ],
            [
                "name" => "Tarakan",
            ],
            [
                "name" => "SO Malinau",
            ],
            [
                "name" => "SO Nunukan",
            ],
            [
                "name" => "SO Tanjung Redeb",
            ],
            [
                "name" => "SO Tanjung Selor",
            ],
            [
                "name" => "SO Mulawarman",
            ],
            [
                "name" => "Makasar",
            ],
            [
                "name" => "SO Balaikota",
            ],
            [
                "name" => "SO Bone",
            ],
            [
                "name" => "SO Gowa",
            ],
            [
                "name" => "SO Panakukang",
            ],
            [
                "name" => "SO Tamalanrea",
            ],
            [
                "name" => "Pare-pare",
            ],
            [
                "name" => "SO Mamuju",
            ],
            [
                "name" => "SO Masamba",
            ],
            [
                "name" => "SO Palopo",
            ],
            [
                "name" => "SO Pare Pare",
            ],
            [
                "name" => "SO Rantepao",
            ],
            [
                "name" => "SO Sengkang",
            ],
            [
                "name" => "SO Wonomulyo",
            ],
            [
                "name" => "Kendari",
            ],
            [
                "name" => "SO Bau-bau",
            ],
            [
                "name" => "SO Kolaka",
            ],
            [
                "name" => "SO Maros",
            ],
            [
                "name" => "SO Bantaeng",
            ],
            [
                "name" => "Gorontalo",
            ],
            [
                "name" => "SO Limboto",
            ],
            [
                "name" => "SO Marisa",
            ],
            [
                "name" => "Palu",
            ],
            [
                "name" => "SO Luwuk",
            ],
            [
                "name" => "SO Palu",
            ],
            [
                "name" => "SO Poso",
            ],
            [
                "name" => "SO Toli-toli",
            ],
            [
                "name" => "Manado",
            ],
            [
                "name" => "SO Bitung",
            ],
            [
                "name" => "SO Kotamobagu",
            ],
            [
                "name" => "SO Manado Centrum",
            ],
            [
                "name" => "SO Ternate",
            ],
            [
                "name" => "SO Halmahera Utara",
            ],
            [
                "name" => "SO Minahasa",
            ],
            [
                "name" => "Ambon",
            ],
            [
                "name" => "SO Masohi",
            ],
            [
                "name" => "SO Tual",
            ],
            [
                "name" => "Jayapura",
            ],
            [
                "name" => "SO Abepura",
            ],
            [
                "name" => "SO Merauke",
            ],
            [
                "name" => "SO Timika",
            ],
            [
                "name" => "Sorong",
            ],
            [
                "name" => "SO Biak",
            ],
            [
                "name" => "SO Fak-fak",
            ],
            [
                "name" => "SO Kaimana",
            ],
            [
                "name" => "SO Manokwari",
            ]
        ]);
    }
}
