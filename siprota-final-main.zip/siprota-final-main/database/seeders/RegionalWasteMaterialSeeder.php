<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

use Illuminate\Support\Facades\DB;

class RegionalWasteMaterialSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $idx = 1;
        for ($i = 1; $i <= 2376; $i++) {
            if ($i < 1104) {
                DB::table('waste_material_gudang')->insert([
                    "waste_material_id" => $idx,
                    "gudang_id" => 1,
                ]);
            }
            if ($i >= 1104 && $i < 1176) {
                DB::table('waste_material_gudang')->insert([
                    "waste_material_id" => $idx,
                    "gudang_id" => 2,
                ]);
            }
            if ($i >= 1176 && $i < 1300) {
                DB::table('waste_material_gudang')->insert([
                    "waste_material_id" => $idx,
                    "gudang_id" => 3,
                ]);
            }
            if ($i >= 1300 && $i < 1599) {
                DB::table('waste_material_gudang')->insert([
                    "waste_material_id" => $idx,
                    "gudang_id" => 4,
                ]);
            }
            if ($i >= 1599 && $i < 2011) {
                DB::table('waste_material_gudang')->insert([
                    "waste_material_id" => $idx,
                    "gudang_id" => 5,
                ]);
            }
            if ($i >= 2011 && $i < 2174) {
                DB::table('waste_material_gudang')->insert([
                    "waste_material_id" => $idx,
                    "gudang_id" => 6,
                ]);
            }
            if ($i >= 2174 && $i <= 2376) {
                DB::table('waste_material_gudang')->insert([
                    "waste_material_id" => $idx,
                    "gudang_id" => 7,
                ]);
            }
            $idx++;
        }
    }
}
