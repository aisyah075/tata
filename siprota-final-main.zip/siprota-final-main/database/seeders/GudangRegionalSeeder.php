<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

use Illuminate\Support\Facades\DB;

class GudangRegionalSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        for ($i = 1; $i <= 403; $i++) {
            if ($i <= 71) {
                DB::table('gudang_regional')->insert([
                    'gudang_id' => $i,
                    'regional_id' => 1,
                ]);
            }
            if ($i <= 150 && $i > 71) {
                DB::table('gudang_regional')->insert([
                    'gudang_id' => $i,
                    'regional_id' => 2,
                ]);
            }
            if ($i <= 186 && $i > 150) {
                DB::table('gudang_regional')->insert([
                    'gudang_id' => $i,
                    'regional_id' => 3,
                ]);
            }
            if ($i <= 236 && $i > 186) {
                DB::table('gudang_regional')->insert([
                    'gudang_id' => $i,
                    'regional_id' => 4,
                ]);
            }
            if ($i <= 314 && $i > 236) {
                DB::table('gudang_regional')->insert([
                    'gudang_id' => $i,
                    'regional_id' => 5,
                ]);
            }
            if ($i <= 356 && $i > 314) {
                DB::table('gudang_regional')->insert([
                    'gudang_id' => $i,
                    'regional_id' => 6,
                ]);
            }
            if ($i <= 402 && $i > 356) {
                DB::table('gudang_regional')->insert([
                    'gudang_id' => $i,
                    'regional_id' => 7,
                ]);
            }
        }
    }
}
