<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\User;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        User::create([
            'name' => 'admin',
            'username' => 'admin',
            'email' => 'admin@localhost',
            'password' => bcrypt('admin'),
        ]);

        User::create([
            'name' => 'Regional 1',
            'username' => 'regional1',
            'email' => 'regional1@localhost',
            'password' => bcrypt('regional1'),
        ]);

        User::create([
            'name' => 'Regional 2',
            'username' => 'regional2',
            'email' => 'regional2@localhost',
            'password' => bcrypt('regional2'),
        ]);

        User::create([
            'name' => 'Regional 3',
            'username' => 'regional3',
            'email' => 'regional3@localhost',
            'password' => bcrypt('regional3'),
        ]);

        User::create([
            'name' => 'Regional 4',
            'username' => 'regional4',
            'email' => 'regional4@localhost',
            'password' => bcrypt('regional4'),
        ]);

        User::create([
            'name' => 'Regional 5',
            'username' => 'regional5',
            'email' => 'regional5@localhost',
            'password' => bcrypt('regional5'),
        ]);

        User::create([
            'name' => 'Regional 6',
            'username' => 'regional6',
            'email' => 'regional6@localhost',
            'password' => bcrypt('regional6'),
        ]);

        User::create([
            'name' => 'Regional 7',
            'username' => 'regional7',
            'email' => 'regional7@localhost',
            'password' => bcrypt('regional7'),
        ]);

        User::create([
            'name' => 'HO',
            'username' => 'ho',
            'email' => 'ho@localhost',
            'password' => bcrypt('ho'),
        ]);
    }
}
