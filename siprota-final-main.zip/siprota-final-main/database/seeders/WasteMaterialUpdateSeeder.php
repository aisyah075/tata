<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\WasteMaterial;

class WasteMaterialUpdateSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        for ($i = 1; $i <= 2376; $i++) {
            $curr_waste = WasteMaterial::where('id', $i)->first();;
            $year_random = 2023;
            $month_random = rand(1, 12);
            $day_random = rand(1, 28);
            // convert day to int
            $month_string = '';
            if ($month_random == 1) {
                $month_string = 1;
            } else if ($month_random == 2) {
                $month_string = 2;
            } else if ($month_random == 3) {
                $month_string = 3;
            } else if ($month_random == 4) {
                $month_string = 4;
            } else if ($month_random == 5) {
                $month_string = 5;
            } else if ($month_random == 6) {
                $month_string = 6;
            } else if ($month_random == 7) {
                $month_string = 7;
            } else if ($month_random == 8) {
                $month_string = 8;
            } else if ($month_random == 9) {
                $month_string = 9;
            } else if ($month_random == 10) {
                $month_string = 10;
            } else if ($month_random == 11) {
                $month_string = 11;
            } else if ($month_random == 12) {
                $month_string = 12;
            }
            $curr_waste->tahun_masuk = $year_random;
            $curr_waste->bulan_masuk = $month_string;
            $curr_waste->tanggal_masuk = $day_random;
            $curr_waste->save();
        }
    }
}
