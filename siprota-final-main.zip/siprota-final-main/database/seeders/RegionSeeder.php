<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class RegionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('regionals')->insert([
            [
                'name' => 'Sumatra',
            ],
            [
                'name' => 'Jakarta',
            ],
            [
                'name' => 'Jawa Barat',
            ],
            [
                'name' => 'Jawa Tengah'
            ],
            [
                'name' => 'Jawa Timur Balinusa'
            ],
            [
                'name' => 'Kalimantan',
            ],
            [
                'name' => 'KTI'
            ]
        ]);
    }
}
