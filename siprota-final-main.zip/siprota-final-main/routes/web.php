<?php

use App\Http\Controllers\ExcelController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\RegionalController;
use App\Http\Controllers\GudangController;
use App\Http\Controllers\WasteMaterialController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\Auth\LoginController;

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/


Route::get('/', function () {
    // return to dashboard
    return redirect()->route('dashboard.index');
});

Auth::routes();
// Route::middleware(['guest'])->group(function () {
//     Route::get('/login', [LoginController::class, 'showLoginForm'])->name('login');
//     Route::post('/login', [LoginController::class, 'login']);
// });
Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::middleware(['auth'])->group(function () {
    Route::resource('dashboard', DashboardController::class);


    Route::resource('/user', UserController::class);

    Route::resource('/region', RegionalController::class);

    Route::resource('/werehouse', GudangController::class);

    Route::resource('waste-material', WasteMaterialController::class);

    Route::get('/waste-material/get-region/{id}', [WasteMaterialController::class, 'getRegion'])->name('waste-material.get-region');
    Route::get('/waste-material/pdf/{id}', [WasteMaterialController::class, 'pdf'])->name('waste-material.pdf');
    Route::get('/waste-material/excel/download', [ExcelController::class, 'excel'])->name('waste-material.excel');
    Route::get('/waste-material/chart/{id}', [WasteMaterialController::class, 'chart'])->name('waste-material.chart');
    Route::get('/waste-material/lihat-foto/{id}', [WasteMaterialController::class, 'lihatFoto'])->name('waste-material.lihat-foto');
});
