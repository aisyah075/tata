Developed by [Danen](github.com/danendra10)

Tutorial [here](https://youtu.be/BbOx48bVHZk)
### Ways to install

1. Dependencies

- node js
Jika menggunakan Linux atau MacOS, jika menggunakan windows, gunakan [link ini](https://www.freecodecamp.org/news/nvm-for-windows-how-to-download-and-install-node-version-manager-in-windows-10/)
```bash
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.38.0/install.sh
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.38.0/install.sh | bash
source ~/.bashrc
nvm list-remote
nvm install v18.12.1
nvm install lts/hydrogen
nvm use v18.12.1
```

- Php 8.1
[Windows](https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=&cad=rja&uact=8&ved=2ahUKEwiz8vvyvcL9AhWnF7cAHb-nCswQFnoECBEQAw&url=https%3A%2F%2Fwww.educative.io%2Fanswers%2Fhow-to-install-php-8-on-windows&usg=AOvVaw0mUz6DAAJmCTNS0RRYs9HZ)

[Linux](https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=&cad=rja&uact=8&ved=2ahUKEwjc3aWDvsL9AhUeHLcAHSUKAIgQFnoECBIQAw&url=https%3A%2F%2Fmedium.com%2F%40laraveltuts%2Fhow-to-install-and-run-php-8-x-on-ubuntu-20-04-8f18e7565c41&usg=AOvVaw3sQbQoJscHayykgE8rqwCa)

[Mac OS](https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=&cad=rja&uact=8&ved=2ahUKEwjq2tCTvsL9AhUhhOYKHYMsDPQQFnoECAsQAQ&url=https%3A%2F%2Fwww.scriptcase.net%2Fdocs%2Fen_us%2Fv9%2Fmanual%2F02-scriptcase-installation%2F07-mac_php%2F&usg=AOvVaw1QxvpSfmPHXbKhbRBjP2GQ)

- Composer

[Linux](https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=&ved=2ahUKEwi7qLT-vsL9AhV1BbcAHasTAJAQFnoECAoQAQ&url=https%3A%2F%2Fwww.digitalocean.com%2Fcommunity%2Ftutorials%2Fhow-to-install-and-use-composer-on-ubuntu-20-04&usg=AOvVaw0FUSOmMNmLlTnz-lCjC7o-)

[Windows](https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=&cad=rja&uact=8&ved=2ahUKEwjliMiQv8L9AhWAm9gFHR08CQcQFnoECBEQAw&url=https%3A%2F%2Fwww.geeksforgeeks.org%2Fhow-to-install-php-composer-on-windows%2F&usg=AOvVaw3N_AnCR1I7Wc29qG0zLw6m)

[Mac](https://www.javatpoint.com/how-to-install-composer-on-mac)

