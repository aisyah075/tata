<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class WasteMaterial extends Model
{
    use HasFactory;

    protected $fillable = [
        'id_barang',
        'nama_barang',
        'jenis_barang',
        'kategori',
        'volume',
        'satuan',
        'keterangan',
        'tahun_produksi',
        'tahun_masuk',
        'bulan_masuk',
        'tanggal_masuk',
        'foto'
    ];

    public function gudangs()
    {
        return $this->belongsToMany(Gudang::class);
    }
}
