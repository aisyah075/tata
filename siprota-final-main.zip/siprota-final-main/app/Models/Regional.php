<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Regional extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
    ];

    public function gudangs()
    {
        return $this->belongsToMany(Gudang::class);
    }
    public function wasteMaterials()
    {
        return $this->hasManyThrough(WasteMaterial::class, Gudang::class);
    }
}
