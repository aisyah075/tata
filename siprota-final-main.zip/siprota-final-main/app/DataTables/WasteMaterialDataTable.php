<?php

namespace App\DataTables;

use App\Models\WasteMaterial;
use Illuminate\Database\Eloquent\Builder as QueryBuilder;
use Yajra\DataTables\EloquentDataTable;
use Yajra\DataTables\Html\Builder as HtmlBuilder;
use Yajra\DataTables\Html\Button;
use Yajra\DataTables\Html\Column;
use Yajra\DataTables\Html\Editor\Editor;
use Yajra\DataTables\Html\Editor\Fields;
use Yajra\DataTables\Services\DataTable;

class WasteMaterialDataTable extends DataTable
{
    /**
     * Build the DataTable class.
     *
     * @param QueryBuilder $query Results from query() method.
     */
    public function dataTable($query)
    {
        return datatables()
            ->eloquent($query)
            ->addColumn('delete', function ($query) {
                return '<a href="' . route('waste-material.destroy', $query->id) . '" class="btn btn-sm btn-danger shadow-sm"><i class="glyphicon glyphicon-edit"></i> Delete</a>';
            })
            ->addColumn('edit', function ($query) {
                return '<a href="' . route('waste-material.edit', $query->id) . '" class="btn btn-sm btn-success shadow-sm"><i class="glyphicon glyphicon-edit"></i> Edit</a>';
            })
            ->addColumn('show', function ($query) {
                return '<a href="' . route('waste-material.show', $query->id) . '" class="btn btn-sm btn-primary shadow-sm"><i class="glyphicon glyphicon-edit"></i> Show</a>';
            })
            ->addColumn('chart', function ($query) {
                return '<a href="' . route('waste-material.chart', $query->id) . '" class="btn btn-sm btn-success shadow-sm"><i class="glyphicon glyphicon-edit"></i> Chart</a>';
            })
            ->addColumn('foto', function ($query) {
                if ($query->foto == null) {
                    return '<a href="' . route('waste-material.edit', $query->id) . '" class="btn btn-xs btn-danger"><i class="glyphicon glyphicon-edit"></i> Tambah</a>';
                }
                return '<a href="' . asset('storage/' . $query->foto) . '" class="btn btn-xs btn-success" target="_blank"><i class="glyphicon glyphicon-edit"></i> Lihat</a>';
            })
            ->addColumn('gudang', function ($query) {
                $gudang = '';
                foreach ($query->gudangs as $key => $value) {
                    $gudang = $value->name;
                }
                if ($gudang == '')
                    return '<a href="' . route('waste-material.edit', $query->id) . '" class="btn btn-xs btn-success"><i class="glyphicon glyphicon-edit"></i> Tambah Gudang</a>';
                return $gudang;
            })
            ->rawColumns(['delete', 'gudang', 'edit', 'show', 'chart', 'foto'])
            ->setRowId('tahun_masuk');
    }

    /**
     * Get the query source of dataTable.
     */
    public function query(WasteMaterial $model)
    {
        // return $model->newQuery();
        $user = auth()->user();
        $role = $user->roles->first()->name;
        if ($role == 'admin' || $role == 'HO') {
            return $model->newQuery();
        }
        // user with role user1 can only see data from region 1
        else if ($role == 'Regional 1') {
            return $model->newQuery()->whereHas('gudangs.regionals', function ($query) {
                $query->where('name', 'Sumatra');
            });
        }
        // user with role user2 can only see data from regional 2
        else if ($role == 'Regional 2') {
            return $model->newQuery()->whereHas('gudangs.regionals', function ($query) {
                $query->where('name', 'Jakarta');
            });
        }
        // user with role user3 can only see data from regional 3
        else if ($role == 'Regional 3') {
            return $model->newQuery()->whereHas('gudangs.regionals', function ($query) {
                $query->where('name', 'Jawa Barat');
            });
        }
        // user with role user4 can only see data from regional 4
        else if ($role == 'Regional 4') {
            return $model->newQuery()->whereHas('gudangs.regionals', function ($query) {
                $query->where('name', 'Jawa Tengah');
            });
        }
        // user with role user5 can only see data from regional 5
        else if ($role == 'Regional 5') {
            return $model->newQuery()->whereHas('gudangs.regionals', function ($query) {
                $query->where('name', 'Jawa Timur Balinusa');
            });
        }
        // user with role user6 can only see data from regional 6
        else if ($role == 'Regional 6') {
            return $model->newQuery()->whereHas('gudangs.regionals', function ($query) {
                $query->where('name', 'Kalimantan');
            });
        }
        // user with role user7 can only see data from regional 7
        else if ($role == 'Regional 7') {
            return $model->newQuery()->whereHas('gudangs.regionals', function ($query) {
                $query->where('name', 'KTI');
            });
        }
    }

    /**
     * Optional method if you want to use the html builder.
     */
    public function html()
    {
        return $this->builder()
            ->setTableId('wastematerial-table')
            ->columns($this->getColumns())
            ->minifiedAjax()
            //->dom('Bfrtip')
            ->orderBy(0, 'asc')
            ->orderBy(1, 'asc')
            ->orderBy(2, 'asc')
            ->selectStyleSingle()
            ->buttons([
                Button::make('add'),
                Button::make('excel'),
                Button::make('csv'),
                Button::make('pdf'),
                Button::make('print'),
                Button::make('reset'),
                Button::make('reload')
            ]);
    }

    /**
     * Get the dataTable columns definition.
     */
    public function getColumns()
    {
        return [
            Column::make('tahun_masuk'),
            Column::make('bulan_masuk'),
            Column::make('tanggal_masuk'),
            Column::make('gudang'),
            Column::make('id_barang'),
            Column::make('nama_barang'),
            Column::make('jenis_barang'),
            Column::make('kategori'),
            Column::make('volume'),
            Column::make('satuan'),
            Column::make('keterangan'),
            Column::make('tahun_produksi'),
            Column::make('foto'),
            Column::make('chart'),
            Column::make('delete'),
            Column::make('show'),
            Column::make('edit'),
        ];
    }

    /**
     * Get the filename for export.
     */
    protected function filename(): string
    {
        return 'WasteMaterial_' . date('YmdHis');
    }
}
