<?php

namespace App\Http\Controllers;

use App\Models\Gudang;
use App\Models\Regional;
use App\Models\WasteMaterial;

use Illuminate\Support\Carbon;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $page_name = 'Dashboard';
        $gudang = Gudang::all()->count();
        $waste_material = WasteMaterial::all()->count();
        $region = Regional::all()->count();
        $waste_material_cnt = WasteMaterial::all()->count();

        $data = WasteMaterial::select('id', 'tahun_masuk')->orderBy('tahun_masuk', 'asc')->get()->groupBy('tahun_masuk');
        $years = [];
        $years_cnt = [];
        foreach ($data as $year => $value) {
            $years[] = $year;
            $years_cnt[] = count($value);
        }

        // count top 10 gudang with most waste material
        $gudang_data = Gudang::withCount('wasteMaterials')->orderBy('waste_materials_count', 'desc')->take(10)->get();
        $gudang_name = [];
        $gudang_cnt = [];
        $minimum_value = 0;
        $maximum_value = 0;
        $max_name = '';
        foreach ($gudang_data as $key => $value) {
            $gudang_name[] = $value->name;
            $gudang_cnt[] = $value->waste_materials_count;
            if ($minimum_value > $value->waste_materials_count) {
                $minimum_value = $value->waste_materials_count;
            }
            if ($maximum_value < $value->waste_materials_count) {
                $maximum_value = $value->waste_materials_count;
                $max_name = $value->name;
            }
        }
        foreach ($gudang_cnt as $key => $value) {
            if ($maximum_value - $minimum_value != 0)
                $gudang_cnt[$key] = ($value - $minimum_value) / ($maximum_value - $minimum_value);
        }
        // dd($years, $years_cnt, $gudang_name, $gudang_cnt);
        $gudang_name = json_encode($gudang_name);
        // remove double quotes replace with single quotes
        $gudang_name = str_replace('"', "'", $gudang_name);
        $myArray = array('foo', 'bar', 'baz');
        $json = json_encode($myArray);
        $max_percentage = ($maximum_value / $waste_material_cnt) * 100;

        return view('index', compact('page_name', 'gudang', 'waste_material', 'region', 'data', 'years', 'years_cnt', 'gudang_name', 'gudang_cnt', 'json', 'max_name', 'max_percentage'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
