<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use \PDF;
use App\Exports\WasteMaterialExport;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Storage;

use App\DataTables\WasteMaterialDataTable;

// Models
use App\Models\WasteMaterial;
use App\Models\Gudang;
use App\Models\Regional;

class WasteMaterialController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(WasteMaterialDataTable $dataTable)
    {
        $page_name = "Waste Material Datas";
        return $dataTable->render('waste_material.index', compact('page_name'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $page_name = "Create Waste Material";
        $gudangs = Gudang::all();
        return view('waste_material.create', compact('page_name', 'gudangs'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        // dd($request->all());
        $id_gudang = $request->gudang;
        $request->request->remove('gudang');
        $imageData = $request->input('foto');
        $request->request->remove('foto');

        // Decode the image data
        $image = base64_decode(preg_replace('#^data:image/\w+;base64,#i', '', $imageData));
        if ($waste = WasteMaterial::create($request->all())) {
            $filename = $waste->id . '.png';
            Storage::disk('public')->put('images/' . $filename, $image);
            $waste->foto = 'images/' . $filename;
            $waste->save();
            $waste_material = WasteMaterial::latest()->first();
            $waste_material->gudangs()->attach($id_gudang);
            return redirect()->route('waste-material.index')->with('success', 'Waste Material Created');
        }
        return redirect()->route('waste-material.index')->with('error', 'Waste Material Failed to Create');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $waste_materials = WasteMaterial::where('id', $id)->first();
        $nama_gudang = $waste_materials->gudangs->first()->name;
        $gudang = Gudang::where('name', $nama_gudang)->first();
        $nama_region = $gudang->regionals->first()->name;
        $page_name = "Show Waste Material";
        return view('waste_material.show', compact('page_name', 'waste_materials', 'nama_region', 'nama_gudang'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $page_name = "Edit Waste Material";
        $waste_material = WasteMaterial::where('id', $id)->first();
        // dd($waste_material);
        $gudangs = Gudang::all();
        return view('waste_material.edit', compact('page_name', 'waste_material', 'gudangs'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        $imageData = $request->input('foto');
        $request->request->remove('foto');

        $image = base64_decode(preg_replace('#^data:image/\w+;base64,#i', '', $imageData));
        $waste_material = WasteMaterial::where('id', $id)->first();
        $filename = $waste_material->id . '.png';
        Storage::disk('public')->put('images/' . $filename, $image);
        $waste_material->foto = 'images/' . $filename;
        $waste_material->gudangs()->sync(request('gudang'));
        $waste_material->save();

        return redirect()->route('waste-material.index')->with('success', 'Waste Material Updated');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $waste_material = WasteMaterial::where('id', $id)->first();
        $waste_material->detach();
        $waste_material->delete();

        return redirect()->route('waste-material.index')->with('success', 'Waste Material Deleted');
    }

    public function getRegion($id)
    {
        $gudang = Gudang::where('id', $id)->first();
        return response()->json($gudang->regionals);
    }

    public function pdf($id)
    {
        $waste_materials = WasteMaterial::where('id', $id)->first();
        $foto_path = storage_path('app/public/' . $waste_materials->foto);
        $foto_url = asset('storage/' . $waste_materials->foto);
        // dd(public_path('/storage/') . $waste_materials->foto);
        $nama_gudang = $waste_materials->gudangs->first()->name;
        $gudang = Gudang::where('name', $nama_gudang)->first();
        $nama_region = $gudang->regionals->first()->name;
        $page_name = "Show Waste Material";
        $pdf = PDF::loadView('waste_material.pdf', compact('page_name', 'waste_materials', 'nama_region', 'nama_gudang', 'foto_url'));
        // return $pdf->stream('waste_material.pdf');
        return $pdf->download('waste_material.pdf');
    }

    public function chart($id)
    {
        $curr_waste_name = WasteMaterial::where('id', $id)->first()->nama_barang;

        $curr_month_number = Carbon::now()->month;
        $same_waste_name = WasteMaterial::where('nama_barang', $curr_waste_name)->where('bulan_masuk', $curr_month_number)->orderBy('tanggal_masuk', 'asc')->get();
        $waste_materials = [];
        $waste_materials_tanggal = [];
        $waste_materials_bulan = '';
        $waste_materials_volume = [];
        foreach ($same_waste_name as $waste) {
            $waste_materials_tanggal[] = $waste->tanggal_masuk;
            $waste_materials_volume[] = $waste->volume;
        }
        $nama_bulan = [
            'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
        ];
        $waste_materials_bulan = $nama_bulan[$curr_month_number - 1];

        $page_name = "Waste Material Chart";
        return view('waste_material.chart', compact('page_name', 'waste_materials_bulan', 'waste_materials_volume', 'waste_materials_tanggal'));
    }

    // public function lihatFoto($id)
    // {

    //     return view('waste_material.lihatFoto', compact('page_name', 'waste_materials', 'nama_region', 'nama_gudang'));
    // }
}
