<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Exports\WasteMaterialExport;
use Maatwebsite\Excel\Facades\Excel;

use App\Models\WasteMaterial;


class ExcelController extends Controller
{
    public function excel()
    {
        // return WasteMaterial::with('gudangs.regionals')->get()->map(function ($wasteMaterial) {
        //     dd($wasteMaterial->gudangs->first()->regionals->first()->name);
        // });
        return Excel::download(new WasteMaterialExport, 'waste_material.xlsx');
    }
}
