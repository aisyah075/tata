<?php

namespace App\Exports;

use App\Models\WasteMaterial;
use Maatwebsite\Excel\Concerns\FromCollection;

class WasteMaterialExport implements FromCollection
{
    /**
     * @return \Illuminate\Support\Collection
     */
    public function collection()
    {
        $header = [
            'Nama Gudang',
            'Nama Region',
            'ID Barang',
            'Nama Barang',
            'Jenis Barang',
            'Kategori',
            'Volume',
            'Satuan',
            'Keterangan',
            'Tahun Produksi',
            'Tahun Masuk',
            'Bulan Masuk',
            'Tanggal Masuk',
        ];
        return WasteMaterial::with('gudangs.regionals')->get()->map(function ($wasteMaterial) {
            if (!empty($wasteMaterial->gudangs->first()))
                $region = $wasteMaterial->gudangs->first()->regionals->first()->name;
            else
                $region = '-';
            // $arr = json_decode($region);
            return [
                'Nama Gudang' => $wasteMaterial->gudangs->pluck('name')->implode(', '),
                'Nama Region' => $region,
                'ID Barang' => $wasteMaterial->id_barang,
                'Nama Barang' => $wasteMaterial->nama_barang,
                'Jenis Barang' => $wasteMaterial->jenis_barang,
                'Kategori' => $wasteMaterial->kategori,
                'Volume' => $wasteMaterial->volume,
                'Satuan' => $wasteMaterial->satuan,
                'Keterangan' => $wasteMaterial->keterangan,
                'Tahun Produksi' => $wasteMaterial->tahun_produksi,
                'Tahun Masuk' => $wasteMaterial->tahun_masuk,
                'Bulan Masuk' => $wasteMaterial->bulan_masuk,
                'Tanggal Masuk' => $wasteMaterial->tanggal_masuk,
            ];
        })->prepend($header);
    }
}
